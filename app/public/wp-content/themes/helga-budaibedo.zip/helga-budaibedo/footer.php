<!-- Codul programatorului vine aici -->
<?php wp_footer(); ?>
 </body>
</html>